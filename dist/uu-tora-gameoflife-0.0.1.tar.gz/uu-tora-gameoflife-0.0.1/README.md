# GameOfLife
Repository for my project in ASPP course

I will work on project suggestion number 1: The Game of Life. 
