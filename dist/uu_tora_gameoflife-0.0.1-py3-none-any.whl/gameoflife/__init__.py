from gameoflife import gameOfLife as gl
